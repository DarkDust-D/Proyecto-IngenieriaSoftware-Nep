require 'test_helper'

class CallsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @call = calls(:one)
  end

  test "should get index" do
    get calls_url
    assert_response :success
  end

  test "should get new" do
    get new_call_url
    assert_response :success
  end

  test "should create call" do
    assert_difference('Call.count') do
      post calls_url, params: { call: { Cargo: @call.Cargo, Ciudad: @call.Ciudad, Cliente: @call.Cliente, Direccion: @call.Direccion, Identificacion: @call.Identificacion, Nombre_Agente: @call.Nombre_Agente, Nombre_Cliente: @call.Nombre_Cliente, Numero_Identificacion: @call.Numero_Identificacion, Objeto: @call.Objeto, Telefono: @call.Telefono } }
    end

    assert_redirected_to call_url(Call.last)
  end

  test "should show call" do
    get call_url(@call)
    assert_response :success
  end

  test "should get edit" do
    get edit_call_url(@call)
    assert_response :success
  end

  test "should update call" do
    patch call_url(@call), params: { call: { Cargo: @call.Cargo, Ciudad: @call.Ciudad, Cliente: @call.Cliente, Direccion: @call.Direccion, Identificacion: @call.Identificacion, Nombre_Agente: @call.Nombre_Agente, Nombre_Cliente: @call.Nombre_Cliente, Numero_Identificacion: @call.Numero_Identificacion, Objeto: @call.Objeto, Telefono: @call.Telefono } }
    assert_redirected_to call_url(@call)
  end

  test "should destroy call" do
    assert_difference('Call.count', -1) do
      delete call_url(@call)
    end

    assert_redirected_to calls_url
  end
end
