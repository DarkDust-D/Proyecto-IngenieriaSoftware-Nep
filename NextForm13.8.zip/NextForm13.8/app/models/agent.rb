class Agent < ApplicationRecord
end
