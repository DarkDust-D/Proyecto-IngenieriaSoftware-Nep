class Client < ApplicationRecord
end
