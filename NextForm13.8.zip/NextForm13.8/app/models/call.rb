class Call < ApplicationRecord

def self.search(search)
if search
  where(["Nombre_Agente LIKE ? OR Nombre_Cliente LIKE ? OR Cargo LIKE ? OR Ciudad LIKE ? OR Cliente LIKE ?","%#{search}%","%#{search}%","%#{search}%","%#{search}%","%#{search}%"])
else
  all
end
end

  validates :Identificacion, presence: true,
  length: { minimum: 1 }

                    validates :Nombre_Agente, presence: true,
                    length: { minimum: 1 }

                    validates :Cargo, presence: true

                    validates :Numero_Identificacion, presence: true,
                    length: { minimum: 1 }

                    validates :Nombre_Cliente, presence: true,
                    length: { minimum: 1 }

                    validates :Direccion, presence: true,
                    length: { minimum: 1 }

                    validates :Telefono, presence: true,
                    length: { minimum: 1 }

                    validates :Cliente, presence: true,
                    numericality: {less_than_or_equal_to: 1},
                    length: { is: 1 }


                    validates :Objeto, presence: true,
                    length: { minimum: 1 }

end
