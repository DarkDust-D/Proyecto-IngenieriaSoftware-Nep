class CreateCalls < ActiveRecord::Migration[5.2]
  def change
    create_table :calls do |t|
      t.text :Identificacion
      t.text :Nombre_Agente
      t.text :Cargo
      t.integer :Numero_Identificacion
      t.text :Nombre_Cliente
      t.text :Direccion
      t.integer :Telefono
      t.text :Ciudad
      t.integer :Cliente
      t.text :Objeto

      t.timestamps
    end
  end
end
