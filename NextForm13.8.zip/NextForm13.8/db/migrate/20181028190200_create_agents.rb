class CreateAgents < ActiveRecord::Migration[5.2]
  def change
    create_table :agents do |t|
      t.text :Identificacion
      t.text :Nombre_Completo
      t.text :Cargo

      t.timestamps
    end
  end
end
